// notas dos 3 alunos
const notas = [
  [8.0, 7.5, 9.0],
  [6.0, 5.0, 7.0],
  [9.5, 8.0, 10.0]
];

// nomes dos alunos
const alunos = ["Paulo", "Yassuaki", "Tamay"];

// pega a tabela do html
const tabela = document.getElementById("tabela-corpo");

// cria as linhas da tabela
for (let i = 0; i < 3; i++) {
  // calcula a media
  let media = (notas[i][0] + notas[i][1] + notas[i][2]) / 3;

  // mostra na tabela
  tabela.innerHTML += `
    <tr>
      <td>${alunos[i]}</td>
      <td>${notas[i][0]}</td>
      <td>${notas[i][1]}</td>
      <td>${notas[i][2]}</td>
      <td>${media.toFixed(1)}</td>
    </tr>
  `;
}
