// matriz com os 3 produtos: nome, preco e quantidade
let produtos = [
  ["Camiseta", 50.00, 10],
  ["Calça Jeans", 120.00, 5],
  ["Tênis", 200.00, 3]
];

// pega os elementos do html
let corpoTabela = document.getElementById("tabela-produtos");
let totalGeralElemento = document.getElementById("valor-total");

let totalGeral = 0;

// loop para percorrer os produtos
for (let i = 0; i < produtos.length; i++) {
  let nome = produtos[i][0];
  let preco = produtos[i][1];
  let quantidade = produtos[i][2];

  // preco x quantidade
  let totalProduto = preco * quantidade;

  // soma no total
  totalGeral += totalProduto;

  // cria a linha da tabela
  let linha = `
    <tr>
      <td>${nome}</td>
      <td>R$ ${preco.toFixed(2)}</td>
      <td>${quantidade}</td>
      <td>R$ ${totalProduto.toFixed(2)}</td>
    </tr>
  `;

  corpoTabela.innerHTML += linha;
}

// exibe o total final
totalGeralElemento.innerText = "R$ " + totalGeral.toFixed(2);
