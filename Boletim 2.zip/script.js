// listas para armazenar os dados
const alunos = [];
const notas = []; // matriz com as 3 notas de cada aluno

// funcao que roda ao clicar no botao
function adicionar() {
  // pega os valores digitados
  const nome = document.getElementById("nome").value;
  const mat = Number(document.getElementById("matematica").value);
  const port = Number(document.getElementById("portugues").value);
  const cien = Number(document.getElementById("ciencias").value);

  // salva o aluno e a linha da matriz
  alunos.push(nome);
  notas.push([mat, port, cien]);

  // calcula a media
  let media = (mat + port + cien) / 3;

  // verifica aprovacao
  let situacao = "Reprovado";
  if (media >= 7) {
    situacao = "Aprovado";
  }

  // coloca o aluno na tabela
  const tabela = document.getElementById("tabela-corpo");
  tabela.innerHTML += `
    <tr>
      <td>${nome}</td>
      <td>${mat}</td>
      <td>${port}</td>
      <td>${cien}</td>
      <td>${media.toFixed(1)}</td>
      <td>${situacao}</td>
    </tr>
  `;

  // limpa os campos para o proximo
  document.getElementById("nome").value = "";
  document.getElementById("matematica").value = "";
  document.getElementById("portugues").value = "";
  document.getElementById("ciencias").value = "";
}
